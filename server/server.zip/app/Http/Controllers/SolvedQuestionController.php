<?php

namespace App\Http\Controllers;

use App\Models\Solved_question;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SolvedQuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(solved_question $solved_question)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(solved_question $solved_question)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, solved_question $solved_question)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(solved_question $solved_question)
    {
        //
    }
}
